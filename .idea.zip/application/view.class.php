<?php

class View
{
    /**
     * Header template
     */
    protected function header(string $page_title = 'Games Rental System'): void
    {
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title><?php echo htmlspecialchars($page_title); ?></title>

            <!-- GLOBAL STYLESHEET -->
            <link rel="stylesheet" href="<?php echo BASE_URL; ?>public/css/style.css">

        </head>
        <body>

        <header>
            <h1>Games Rental System</h1>
            <nav>
                <a href="<?php echo BASE_URL; ?>game/index">Home</a>
            </nav>
        </header>

        <main>
        <?php
    }

    /**
     * Footer template
     */
    protected function footer(): void
    {
        ?>
        </main>

        <footer>
            <p>&copy; <?php echo date('Y'); ?> Group 5 - I211 Final Project</p>
        </footer>

        </body>
        </html>
        <?php
    }
}
