<?php
/*
 * Global configuration file
 * For I211 Final Project – Group 5
 */

// MUST end with slash
define('BASE_URL', '/I211/index-1/');

// Database settings
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');     // <-- MATCHES Database class correctly
define('DB_NAME', 'games_db');

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);
