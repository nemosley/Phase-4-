<?php
abstract class Controller {

    protected function redirect($controller = 'game', $action = 'index', $id = null) {
        $url = BASE_URL . "$controller/$action";
        if ($id !== null) {
            $url .= "/$id";
        }
        header("Location: $url");
        exit;
    }
}
