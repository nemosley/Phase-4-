<?php
/**
 * Author: Nevaeh Mosley
 * File: game_model.class.php
 * Description: Model class for games. Retrieves all games and a specific game.
 */

class GameModel
{
    // Singleton instance
    private static ?GameModel $_instance = null;

    // Database wrapper and mysqli connection
    private Database $db;
    private mysqli $dbConnection;

    // Table name
    private string $tblGame;

    /**
     * Private constructor for singleton.
     */
    private function __construct()
    {
        // Get the Database singleton
        $this->db = Database::getDatabase();

        // Get the actual mysqli connection object
        $this->dbConnection = $this->db->getConnection();

        // Our table name
        $this->tblGame = 'games';
    }

    /**
     * Return the singleton instance of GameModel.
     */
    public static function getGameModel(): GameModel
    {
        if (self::$_instance === null) {
            self::$_instance = new GameModel();
        }
        return self::$_instance;
    }

    /**
     * Get all games (used for the inventory page).
     *
     * @return array
     */
    public function get_all_games(): array
    {
        $games = [];

        $sql = "SELECT * FROM $this->tblGame";
        $query = $this->dbConnection->query($sql);

        if ($query) {
            while ($row = $query->fetch_assoc()) {
                $games[] = $row;
            }
            $query->free();
        }

        return $games;
    }

    /**
     * Get one game by id (used for detail page).
     *
     * @param int $id
     * @return array|null
     */
    public function get_game_by_id(int $id): ?array
    {
        $sql = "SELECT * FROM $this->tblGame WHERE game_id = ?";

        $stmt = $this->dbConnection->prepare($sql);
        if (!$stmt) {
            return null;
        }

        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();

        $game = $result ? $result->fetch_assoc() : null;

        $stmt->close();

        return $game ?: null;
    }

    /**
     * Add a new game to the database.
     *
     * Expects an associative array with keys:
     *  - title
     *  - platform
     *  - category_id
     *  - description
     *  - price
     *  - stock
     *  - available
     *
     * @param array $data
     * @return int|null  New game_id on success, null on failure.
     */
    public function add_game(array $data): ?int
    {
        $sql = "INSERT INTO $this->tblGame
                    (title, platform, category_id, description, price, stock, available)
                VALUES (?, ?, ?, ?, ?, ?, ?)";

        $stmt = $this->dbConnection->prepare($sql);
        if (!$stmt) {
            return null;
        }

        $title       = $data['title'];
        $platform    = $data['platform'];
        $category_id = (int)$data['category_id'];
        $description = $data['description'] ?? null;
        $price       = (float)$data['price'];
        $stock       = (int)$data['stock'];
        $available   = (int)$data['available']; // 0 or 1

        // s = string, i = int, d = double
        // title (s), platform (s), category_id (i), description (s), price (d), stock (i), available (i)
        $stmt->bind_param(
            "ssisdii",
            $title,
            $platform,
            $category_id,
            $description,
            $price,
            $stock,
            $available
        );

        if (!$stmt->execute()) {
            $stmt->close();
            return null;
        }

        $new_id = $stmt->insert_id ?: $this->dbConnection->insert_id;

        $stmt->close();

        return $new_id ?: null;
    }
}
