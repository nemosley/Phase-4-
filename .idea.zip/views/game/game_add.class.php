<?php
/**
 * Game detail view
 */
class GameDetail extends View
{
    public function display(?array $game): void
    {
        $this->header('Game Details');
        ?>
        <section class="game-detail">
            <?php if (!$game): ?>
                <h2>Game Not Found</h2>
                <p>The requested game could not be found.</p>
                <a class="btn-link" href="<?= BASE_URL ?>game/index">Back to Inventory</a>
            <?php else: ?>
                <?php
                // Safely read values with fallbacks
                $title       = htmlspecialchars($game['title'] ?? 'Untitled');
                $platform    = htmlspecialchars($game['platform'] ?? 'N/A');
                $category_id = htmlspecialchars($game['category_id'] ?? 'N/A');
                $description = htmlspecialchars($game['description'] ?? 'No description available.');
                $price       = isset($game['price']) ? number_format((float)$game['price'], 2) : '0.00';
                $stock       = htmlspecialchars($game['stock'] ?? '0');
                $status      = ($game['available'] ?? 1) ? 'Available' : 'Checked Out';
                ?>

                <h2><?= $title ?></h2>

                <p><strong>Platform:</strong> <?= $platform ?></p>
                <p><strong>Category ID:</strong> <?= $category_id ?></p>
                <p><strong>Rental Price:</strong> $<?= $price ?></p>
                <p><strong>Stock:</strong> <?= $stock ?></p>
                <p><strong>Description:</strong><br>
                    <?= nl2br($description) ?>
                </p>
                <p><strong>Status:</strong> <?= htmlspecialchars($status) ?></p>

                <a class="btn-link" href="<?= BASE_URL ?>game/index">Back to Inventory</a>
            <?php endif; ?>
        </section>
        <?php
        $this->footer();
    }
}
