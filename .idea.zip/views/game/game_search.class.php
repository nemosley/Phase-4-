<?php
/**
 *Author:Nevaeh Mosley
 *Date:12/4/2025
 *File:game_search.class.php
 *Description
 */

class GameSearch extends View {
    /*
     * the display method accepts the search terms and an array of game records
     * and displays them in a grid.
     */

    public function display($terms, $games): void
    {
        //display page header
        $this->header("Search Results");
        ?>
        <div id="main-header"> Search Results for <i><?= htmlspecialchars($terms) ?></i></div>
        <span class="rcd-numbers">
            <?php
            echo ((!is_array($games) || empty($games)) ? "( 0 - 0 )" : "( 1 - " . count($games) . " )");
            ?>
        </span>
        <hr>

        <!-- display all records in a grid -->
        <div class="grid-container">
            <?php
            if (!is_array($games) || empty($games)) {
                echo "No game was found.<br><br><br><br><br>";
            } else {
                //display games in a grid; you can style .item in CSS
                foreach ($games as $game) {
                    $id       = $game['game_id']   ?? null;
                    $title    = $game['title']     ?? '';
                    $platform = $game['platform']  ?? '';
                    $category = $game['category_id'] ?? '';
                    $price    = isset($game['price']) ? number_format((float)$game['price'], 2) : '';
                    $status   = ((int)($game['available'] ?? 1) === 1) ? "Available" : "Checked Out";

                    if ($id === null) {
                        continue;
                    }

                    echo "<div class='item'>
                            <p>
                                <a href='" . BASE_URL . "game/detail/" . urlencode($id) . "'>
                                    <span class='game-title'>" . htmlspecialchars($title) . "</span>
                                </a>
                                <span><br>
                                    Platform: " . htmlspecialchars($platform) . "<br>
                                    Category ID: " . htmlspecialchars($category) . "<br>
                                    Price: $" . htmlspecialchars($price) . "<br>
                                    Status: " . htmlspecialchars($status) . "
                                </span>
                            </p>
                          </div>";
                }
            }
            ?>
        </div>
        <a href="<?= BASE_URL ?>game/index">Go to game list</a>
        <?php
        //display page footer
        $this->footer();
    }

    //end of display method
}
