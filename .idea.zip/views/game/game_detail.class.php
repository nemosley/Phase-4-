<?php
/**
 * Game detail view
 */
class GameDetail extends View
{
    public function display(?array $game): void
    {
        $this->header('Game Details');
        ?>
        <section class="game-detail">
            <?php if (!$game): ?>
                <h2>Game Not Found</h2>
                <p>The requested game could not be found.</p>
                <a class="btn-link" href="<?php echo BASE_URL; ?>game/index">Back to Inventory</a>
            <?php else: ?>
                <?php
                // Safely read values with fallbacks
                $title       = htmlspecialchars($game['title'] ?? 'Untitled');
                $platform    = htmlspecialchars($game['platform'] ?? 'N/A');
                $genre       = htmlspecialchars($game['genre'] ?? 'N/A');
                $description = htmlspecialchars($game['description'] ?? 'No description available.');
                $status      = htmlspecialchars(($game['available'] ?? 1) ? 'Available' : 'Checked Out');
                ?>

                <h2><?php echo $title; ?></h2>

                <p><strong>Platform:</strong> <?php echo $platform; ?></p>
                <p><strong>Genre:</strong> <?php echo $genre; ?></p>
                <p><strong>Description:</strong><br>
                    <?php echo nl2br($description); ?>
                </p>
                <p><strong>Status:</strong> <?php echo $status; ?></p>

                <a class="btn-link" href="<?php echo BASE_URL; ?>game/index">Back to Inventory</a>
            <?php endif; ?>
        </section>
        <?php
        $this->footer();
    }
}
