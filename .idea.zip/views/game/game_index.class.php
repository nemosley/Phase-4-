<?php
/*
 * Author: Nevaeh Mosley
 * Date: 12/04/2025
 * Name: game_index.class.php
 * Description: this script defines the GameIndex class. The class contains a method named display,
 *     which accepts an array of game records and displays them in a table (games inventory).
 */

class GameIndex extends View
{
    public function display(array $games): void
    {
        //display page header
        $this->header("Games Inventory");
        ?>

        <h2>Games Inventory</h2>

        <!-- SEARCH BAR (hidden AND/OR logic) -->
        <form action="<?= BASE_URL ?>game/search" method="get" class="search-bar">

            <input type="text"
                   name="query-terms"
                   placeholder="Search games (multiple words allowed)..."
                   value="<?= isset($_GET['query-terms']) ? htmlspecialchars($_GET['query-terms']) : '' ?>"
                   required>

            <!-- AND/OR still exists for backend but hidden -->
            <input type="hidden" name="mode" value="AND">

            <button type="submit">Search</button>
        </form>

        <!-- Link to create (add new game) feature -->
        <p>
            <a href="<?= BASE_URL ?>game/create">+ Add New Game</a>
        </p>

        <?php if (empty($games)) : ?>
        <p>No games found.</p>
    <?php else : ?>
        <table class="games-table">
            <thead>
            <tr>
                <th>Title</th>
                <th>Platform</th>
                <th>Category ID</th>
                <th>Status</th>
                <th>Details</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($games as $game) : ?>
                <tr>
                    <td><?= htmlspecialchars($game['title'] ?? '') ?></td>
                    <td><?= htmlspecialchars($game['platform'] ?? '') ?></td>
                    <td><?= htmlspecialchars($game['category_id'] ?? '') ?></td>
                    <td><?= ($game['available'] ?? 1) ? 'Available' : 'Checked Out' ?></td>
                    <td>
                        <?php if (!empty($game['game_id'])) : ?>
                            <a href="<?= BASE_URL . 'game/detail/' . urlencode($game['game_id']) ?>">View</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>

        <?php
        //display page footer
        $this->footer();
    }
}

