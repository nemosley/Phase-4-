<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);



require_once __DIR__ . '/vendor/autoload.php';
require_once __DIR__ . '/application/config.php';

// Get controller/action/id from query (set by .htaccess rewrite)
$controller = $_GET['controller'] ?? 'game';
$action     = $_GET['action'] ?? 'index';
$id         = $_GET['id'] ?? null;

// Build controller class name, e.g., "GameController"
$controller_class = ucfirst($controller) . 'Controller';

// Does controller exist?
if (!class_exists($controller_class)) {
    echo "Controller '$controller_class' not found.";
    exit;
}

$ctrl = new $controller_class();

// Does method exist?
if (!method_exists($ctrl, $action)) {
    echo "Action '$action' not found.";
    exit;
}

// Call controller method
if ($id !== null && $id !== '') {
    $ctrl->$action($id);
} else {
    $ctrl->$action();
}
